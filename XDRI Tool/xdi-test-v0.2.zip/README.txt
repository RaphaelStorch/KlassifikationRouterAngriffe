Windows
-------

Click xdi-test-v0.1.exe to test the resolver configured on your system or run xdi-test-v0.1.exe resolver-ip to test a different resolver.


Other OS
--------

Install the required python packages listed in requirements.txt and start the tool via python xdi-test-v0.1.py.

